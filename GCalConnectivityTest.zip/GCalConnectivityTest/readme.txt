Google Calendar Connectivity Test verifies that a Java application can successfully
connect to Google Calendar.

To run the app under Windows, use gcalconntest.vbs.
To run the app under Linux or OS X, use gcalconntest.sh.

If you get an error, read the Troubleshooting section of the LNGS HelpFile.html file.
If you need additional help, post to the Open Discussion forum:
https://sourceforge.net/projects/lngooglecalsync/forums 
